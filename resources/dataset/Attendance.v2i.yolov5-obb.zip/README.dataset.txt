# Attendance > 2024-12-17 5:20pm
https://universe.roboflow.com/project-yle3g/attendance-308wy

Provided by a Roboflow user
License: CC BY 4.0

